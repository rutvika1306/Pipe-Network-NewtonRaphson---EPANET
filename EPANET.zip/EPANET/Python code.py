# -*- coding: utf-8 -*-
"""
Created on Sun Mar 23 11:01:21 2025

@author: rutvi
"""
import numpy as np

#roll no - 241030069
x,y=6,9
p=10*x + y

#resistance for the pipes
R1=120 + p
R2=300 + p
R3=200 + p
R4=150 + p
R5,R6,R7,R8=400 + p,400 + p,400 + p,400 + p
Qin = 5
Qout1 = 3
Qout2 = 2

def equation(Q):
    Q1,Q2,Q3,Q4,Q5,Q6,Q7,Q8=Q
    
    #flow conservation equations at nodes
    eqn1=Q1-Q5-Q3    #at node 1
    eqn2=Q7-Q6+Q5-Q8    #at node 2
    eqn3=Qin-Q1-Q7-Q3   #at node 3
    eqn4=Q2+Q8+Q4-Qout1       #at node 4
    
    #head loss equations for loops
    eqn5=(R1*abs(Q1)*Q1)+(R5*abs(Q5)*Q5)-(R7*abs(Q7)*Q7)      #at loop 1
    eqn6=-(R5*abs(Q5)*Q5)+(R2*abs(Q2)*Q2)-(R8*abs(Q8)*Q8)        #at loop 2
    eqn7=(R7*abs(Q7)*Q7)+(R6*abs(Q6)*Q6)-(R3*abs(Q3)*Q3)        #at loop 3
    eqn8=-(R6*abs(Q6)*Q6)+(R8*abs(Q8)*Q8)-(R4*abs(Q4)*Q4)        #at loop 4
    
    return np.array([eqn1, eqn2, eqn3, eqn4, eqn5, eqn6, eqn7, eqn8])


def jacobian(Q, h=1e-6):
    
    n = len(Q)            #number of equations
    J = np.zeros((n, n))  #initializing an empty Jacobian matrix

    f_original = equation(Q)                #computing function values at current Q

    for i in range(n):
        Q_modified = Q.copy()             #make a copy of Q to modify safely
        Q_modified[i] += h             #slightly increasing only the i-th variable

        f_new = equation(Q_modified)         #new function values at modified Q

        #computing derivative using the difference formula
        for j in range(n):
            J[j][i] = (f_new[j] - f_original[j]) / h

    return J  # Return the computed Jacobian matrix

def newton_raphson(Q_init):
    Q = np.array(Q_init)  #convert initial guess to numpy array

    for i in range(100):  #run the loop for 100 iteration 
        F = equation(Q)  #computing function values
        J = jacobian(Q)   #computing Jacobian matrix
        
        error = np.linalg.norm(F)  # measuring error
        print(f"Iteration {i+1}: Error = {error:.6f}")

        if error < 1e-6:  #solution is found if the error is small than  tolerance
            print("Converged successfully!")
            return Q

        #check if Jacobian is singular (non-invertible)
        if np.linalg.det(J) == 0:
            raise ValueError("Jacobian is singular. Try a different initial guess.")

        delta_Q = np.linalg.solve(J, -np.array(F))  #solving for step size
        Q = Q + delta_Q                  #updating Q values

        step_size = np.linalg.norm(delta_Q)  #check how much Q changed
        if step_size < 1e-6:  #stoppping if change in Q is smaller than tolerance
            print("Solution is stable, stopping iteration.")
            return Q

    print("Newton-Raphson method did not converge.")
    
    return Q         #returning the last computed values

   
    
Qguess=[2.0, 2.0, 1.5, 1.5, 1.0, 1.0, 0.5, 0.5]        #initial guess for discharge in each pipe

solution = newton_raphson(Qguess)         #solving the non linear equation


print("The Discharge in each pipe is : ")

for i in range(len(solution)):
    print(f"Pipe P{i+1} : Q{i+1} = {solution[i]:.4f} units")


    
